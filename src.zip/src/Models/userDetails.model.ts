export interface IUserDetails {
    userName: string,
    userId: number,
    isAdmin: number,
    iat: number,
    message:string
}